Put "Epic Knights Int" into "WORLD_NAME"/datapacks/
1.16.5

---------

Засунь папку "Epic Knights Int" в "ИМЯ_МИРА"/datapacks/
1.16.5
